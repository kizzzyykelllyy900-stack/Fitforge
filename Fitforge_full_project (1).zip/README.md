# FitForge 🏋️‍♂️

AI-powered fitness and wellness app — helping users forge strength, balance, and health.

## Stack
- FastAPI (Backend)
- React + Vite (Frontend)
- Render for deployment

## Run locally
```bash
# Backend
cd backend
uvicorn main:app --reload

# Frontend
cd frontend
npm install
npm run dev
```
