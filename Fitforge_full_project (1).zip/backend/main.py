from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import fitness, nutrition, user

app = FastAPI(title="FitForge API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(fitness.router, prefix="/api/fitness", tags=["Fitness"])
app.include_router(nutrition.router, prefix="/api/nutrition", tags=["Nutrition"])
app.include_router(user.router, prefix="/api/user", tags=["User"])

@app.get("/")
def root():
    return {"message": "Welcome to FitForge API"}
