from fastapi import APIRouter
from services.ai_advice import generate_fitness_tip

router = APIRouter()

@router.get("/tip")
def get_fitness_tip():
    tip = generate_fitness_tip()
    return {"tip": tip}
