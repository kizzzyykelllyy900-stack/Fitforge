from fastapi import APIRouter

router = APIRouter()

@router.get("/meal-plan")
def get_meal_plan():
    return {"meal_plan": "Eat balanced meals with proteins, carbs, and fats."}
