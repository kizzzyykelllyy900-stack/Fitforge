from fastapi import APIRouter

router = APIRouter()

@router.get("/profile")
def get_profile():
    return {"user": "FitForge User", "level": "Beginner"}
