import random

def generate_fitness_tip():
    tips = [
        "Stay consistent — small progress every day adds up.",
        "Hydration is key: drink water before, during, and after workouts.",
        "Balance your strength and cardio sessions for full-body fitness.",
        "Proper form is better than heavier weights — always prioritize safety.",
        "Rest and recovery are just as important as training."
    ]
    return random.choice(tips)
