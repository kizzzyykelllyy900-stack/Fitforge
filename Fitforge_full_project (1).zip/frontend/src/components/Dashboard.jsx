import React, { useState, useEffect } from 'react';

export default function Dashboard() {
  const [tip, setTip] = useState("");

  useEffect(() => {
    fetch("https://fitforge-9097.onrender.com/api/fitness/tip")
      .then(res => res.json())
      .then(data => setTip(data.tip))
      .catch(() => setTip("Welcome back to FitForge!"));
  }, []);

  return (
    <div className="dashboard">
      <h2>Welcome to FitForge</h2>
      <p>{tip}</p>
    </div>
  );
}
