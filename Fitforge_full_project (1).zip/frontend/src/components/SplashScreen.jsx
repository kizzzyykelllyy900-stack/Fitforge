import React from 'react';

export default function SplashScreen() {
  return (
    <div className="splash">
      <h1>FitForge</h1>
      <p>Forging Strength Through AI</p>
    </div>
  );
}
